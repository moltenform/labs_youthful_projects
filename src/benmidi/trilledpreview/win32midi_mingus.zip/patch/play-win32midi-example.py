#!/usr/bin/env python
"""

*** Description ***

	Converts a progression to chords and plays them using synth.

	You should specify the SF2 soundfont file.

"""

from mingus.core import progressions, intervals
from mingus.core import chords as ch
from mingus.containers import NoteContainer, Note

import time, sys
from random import random

if True:
	from mingus.midi import win32midisequencer
	synth = win32midisequencer.Win32MidiSequencer()
else:
	from mingus.midi import fluidsynth
	synth = fluidsynth
	
synth.set_instrument(1, 73) # (test program change) Flute.
synth.control_change(1, 0x07, 128) #setting volume. (test controller change)

progression = ["I", "vi", "ii", "iii7",
	       "I7", "viidom7", "iii7", "V7"]
key = 'C'

chords = progressions.to_chords(progression, key)

listnotes = [Note("C", 4),Note("D", 4),Note("E", 4),  [Note("C", 4), Note("E", 4)],[Note("D", 4), Note("F", 4)],[Note("E", 4), Note("G", 4)]]
for note in listnotes:
	c = NoteContainer(note)
	synth.play_NoteContainer(c)
	time.sleep(0.45)
	synth.stop_NoteContainer(c)

