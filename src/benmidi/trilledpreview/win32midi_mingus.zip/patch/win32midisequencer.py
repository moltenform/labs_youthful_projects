"""
   Win32MidiSequencer, by Ben Fisher, 2009

   This module provides midi playback support for mingus in Windows. 
   It will use the default midi output device, which can be chosen in control panel.
   No extra dlls or modules are needed, uses built-in ctypes module.
   
   Caution: this will throw Win32MidiException if there is no device, or device can't be opened
"""

import sys
# we should be able to import this module on non-win32 systems without raising exception.
# so instead, raise in the init() method.
if sys.platform=='win32':
	import win32midi
	from win32midi import Win32MidiException
	
from datetime import datetime
from mingus.midi.Sequencer import Sequencer
from mingus.containers.Instrument import MidiInstrument

class Win32MidiSequencer(Sequencer):
	output = None
	midplayer = None

	def init(self):
		if sys.platform!='win32': raise 'Intended for use on win32 platform'
		self.midplayer = win32midi.Win32MidiPlayer()
		self.midplayer.openDevice()

	def __del__(self):
		self.midplayer.closeDevice()

	# Implement Sequencer's interface
	def play_event(self, note, channel, velocity):
		self.midplayer.rawNoteOn(note, channel, velocity)

	def stop_event(self, note, channel):
		self.midplayer.rawNoteOff(note, channel)

	def cc_event(self, channel, control, value):
		self.midplayer.controllerChange(control,value, channel)

	def instr_event(self, channel, instr, bank):
		#"bank" currently not supported
		self.midplayer.programChange(instr, channel)


#fluidsynth.py creates a global object called "midi". 
# Perhaps this could be changed to allow choosing to use Win32midi as the default synth
# midi = Win32MidiSequencer()
# initialized = False
# ...


