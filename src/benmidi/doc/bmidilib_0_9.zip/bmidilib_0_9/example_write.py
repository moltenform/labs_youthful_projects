#see readme.txt, bbuilder.py, and the online documentation for more examples.

from bmidilib import bbuilder
b = bbuilder.BMidiBuilder()
b.note('c', 1)
b.note('d', 1)
b.note('e', 1)
b.note('f', 1)
b.note('g', 4)
b.save('out.mid')

