from bmidilib import bmidilib
	
m = bmidilib.BMidiFile()
m.open('sample.mid')
m.read()
m.close()
print m 
#lists all of the events in a human-readable way

#loop through only the note events in 2nd track, and print out pitches and durations
for note in m.tracks[1].notelist:
	print note.pitch, note.duration