		
		
class Callable():
	def __init__(self, func, *args, **kwds):
		self.func = func
		self.args = args
		self.kwds = kwds
	def __call__(self, event=None):
		return apply(self.func, self.args, self.kwds)
	def __str__(self):
		return self.func.__name__

def makeThread(fn, args):
	import threading
	class MyThread(threading.Thread):
		"""this is a wrapper for threading.Thread that improves the syntax for creating and starting threads - Allen Downey"""
		def __init__(self, target, *args):
			threading.Thread.__init__(self, target=target, args=args)
			self.start()
	MyThread(fn, args)

def ask_openfile(initialfolder='.',title='Open',types=None):
	"""Open a native file dialog that asks the user to choose a file. The path is returned as a string.
	Specify types in the format ['.bmp|Windows Bitmap','.gif|Gif image'] and so on.
	"""
	import tkFileDialog
	# for the underlying tkinter, Specify types in the format type='.bmp' types=[('Windows bitmap','.bmp')]
	if types!=None:
		aTypes = [(type.split('|')[1],type.split('|')[0]) for type in types]
		defaultExtension = aTypes[0][1]
		strFiles = tkFileDialog.askopenfilename(initialdir=initialfolder,title=title,defaultextension=defaultExtension,filetypes=aTypes)
	else:
		strFiles = tkFileDialog.askopenfilename(initialdir=initialfolder,title=title)
	return strFiles

def ask_savefile(initialfolder='.',title='Save As',types=None):
	"""Open a native file "save as" dialog that asks the user to choose a filename. The path is returned as a string.
	Specify types in the format ['.bmp|Windows Bitmap','.gif|Gif image'] and so on.
	"""
	import tkFileDialog
	if types!=None:
		aTypes = [(type.split('|')[1],type.split('|')[0]) for type in types]
		defaultExtension = aTypes[0][1]
		strFiles = tkFileDialog.asksaveasfilename(initialdir=initialfolder,title=title,defaultextension=defaultExtension,filetypes=aTypes)
	else:
		strFiles = tkFileDialog.asksaveasfilename(initialdir=initialfolder,title=title)
	return strFiles

def alert(message, title=None, icon='info'):
	""" Show dialog with information. Icon can be one of 'info','warning','error', defaulting to 'info'."""
	import tkMessageBox
	if icon=='info':
		return tkMessageBox.showinfo(title=title, message=message)
	elif icon=='warning':
		return tkMessageBox.showwarning(title=title, message=message)
	elif icon=='error':
		return tkMessageBox.showerror(title=title, message=message)
	